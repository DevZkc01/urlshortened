<?php

namespace App\Http\Controllers;

use App\Models\Url;
use Illuminate\Http\Request;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class UrlController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('urls.index');
    }


    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    { 
        request()->validate(['lien' => 'required|url']);
        
        $url_create = Url::where('lien',request('lien'))->first();

       if($url_create){
        return view('urls.show')->with([
                                        'urlshoter' => $url_create->urlshoter,
                                        'urls' => $url_create
                                        ]);
       }
       
        
        $qrcode = QrCode::size(200)->generate(request()->lien);
        $url_create = Url::create([
            'lien' => request('lien'),
            'urlshoter' => Url::generation_short_url(),
            'qrcodeUrl' => $qrcode
        ]);

         if($url_create) 
        {
             return view('urls.show')->with([
                                        'urlshoter' => $url_create->urlshoter,
                                        'urls' => $url_create
                                        ]);
        }
    }  

    public function show($urlshoter)
    {
        $url = Url::where('urlshoter',request('urlshoter'))->first();

        if(!$url)
        {
            return redirect('/');
        }else{
            return redirect($url->lien);
        }
    }
        
}