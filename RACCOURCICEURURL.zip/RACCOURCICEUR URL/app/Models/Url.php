<?php

namespace App\Models;

use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Url extends Model
{
    use HasFactory;
    protected $guarded = [];
    public static  function generation_short_url()
    {
       
        $urlshoter = Str::random(5);

        if(Url::whereUrlshoter($urlshoter)->first())
        { 
            return static::generation_short_url();
        }
        return $urlshoter;
    }
}