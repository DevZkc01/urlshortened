

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('navbar.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-4">

    <h1 class="text-center">
        Résultat
    </h1>

    <div class="row text-center">


        <a href="<?php echo e(config('app.url')); ?>/<?php echo e($urlshoter); ?>">
            <?php echo e(config('app.url')); ?>/<?php echo e($urlshoter); ?>

        </a>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\LARAVEL\PROJET LARAVEL\RACCOURCICEUR URL\resources\views/resultat.blade.php ENDPATH**/ ?>