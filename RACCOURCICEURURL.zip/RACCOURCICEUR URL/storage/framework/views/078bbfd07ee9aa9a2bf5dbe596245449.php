

<?php $__env->startSection('content'); ?>


<div class="min-h-full">
    <nav class="bg-gray-800">
        <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div class="flex h-16 items-center justify-between">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <img class="h-8 w-8" src="<?php echo e(asset('images/logo.png')); ?>" alt="TDAC The Corporate">
                    </div>
                    <div class="hidden md:block">
                        <div class="ml-10 flex items-baseline space-x-4">
                            <!-- Current: "bg-gray-900 text-white", Default: "text-gray-300 hover:bg-gray-700 hover:text-white" -->
                            <a href="#" class="bg-gray-900 text-white rounded-md px-3 py-2 text-sm font-medium"
                                aria-current="page">Nos Services</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Mobile menu, show/hide based on menu state. -->
        <div class="md:hidden" id="mobile-menu">
            <div class="space-y-1 px-2 pb-3 pt-2 sm:px-3">
                <!-- Current: "bg-gray-900 text-white", Default: "text-gray-300 hover:bg-gray-700 hover:text-white" -->
                <a href="<?php echo e(route('url.index')); ?>"
                    class="bg-gray-900 text-white block rounded-md px-3 py-2 text-base font-medium"
                    aria-current="page">Acceuil</a>
            </div>
        </div>
    </nav>

    <header class="bg-white shadow">
        <div class="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
            <h1 class="text-3xl font-bold tracking-tight text-gray-900">Url Shorted</h1>
        </div>
    </header>
    <main>

        <?php echo $__env->make('defilement.defile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="mx-auto max-w-7xl py-6 sm:px-6 lg:px-8">
            <div class="text-center">
                Url de départ : <a href="<?php echo e($urls->lien); ?> "><?php echo e($urls->lien); ?></a> <br>
                Nouveau Url : <a href="<?php echo e(config('app.url')); ?>/<?php echo e($urlshoter); ?>">
                    <?php echo e(config('app.url')); ?>/<?php echo e($urlshoter); ?>

                </a>
                <p class="text-center mx-auto"> <?php echo $urls->qrcodeUrl; ?> </p>
            </div>
        </div>

        <div class="mx-auto text-2xl text-center max-w-7xl py-6 sm:px-6 lg:px-8">
            Merci d'avoir opté pour nous, car plus 1 millions ont choisi notre solution !!!
        </div>
    </main>
</div>

<!-- <div class="container mt-4">

    <h1 class="text-center">
        Résultat
    </h1>

    <div class="row text-center">

        <h5 class="text-center">
            Url : <a href="<?php echo e($urls->lien); ?>"><?php echo e($urls->lien); ?></a>
        </h5>
        <a href="<?php echo e(config('app.url')); ?>/<?php echo e($urlshoter); ?>">
            <?php echo e(config('app.url')); ?>/<?php echo e($urlshoter); ?>

        </a>
        <?php echo $urls->qrcodeUrl; ?>

    </div>
</div> -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH R:\LARAVEL\PROJET LARAVEL\RACCOURCICEUR URL\resources\views/urls/show.blade.php ENDPATH**/ ?>