 <div class="container">
     <marquee behavior="alternate" class="ml-4 mr-4 text-4xl mt-4 text-sky-500 font-bold" direction="right">
         Soyez le bienvenu, sur notre plateforme ShortUrl
     </marquee>
 </div><?php /**PATH R:\LARAVEL\PROJET LARAVEL\RACCOURCICEUR URL\resources\views/defilement/defile.blade.php ENDPATH**/ ?>