<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo e(asset('bootstrap/bootstrap.min.css')); ?>" rel="stylesheet" crossorigin="anonymous">
    <title>Urls Shorter</title>
    <link rel="shortcut icon" href="<?php echo e(asset('images/tdac_prev_ui.ico')); ?>" />
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body>


    <?php echo $__env->yieldContent('content'); ?>


    <script src="<?php echo e(asset('bootstrap/bootstrap.bundle.min.js')); ?>" crossorigin="anonymous">
    </script>
</body>

</html><?php /**PATH R:\LARAVEL\PROJET LARAVEL\RACCOURCICEUR URL\resources\views/layouts/master.blade.php ENDPATH**/ ?>