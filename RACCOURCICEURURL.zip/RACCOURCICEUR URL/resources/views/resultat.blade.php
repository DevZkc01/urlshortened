@extends('layouts.master')

@section('content')

@include('navbar.navbar')

<div class="container mt-4">

    <h1 class="text-center">
        Résultat
    </h1>

    <div class="row text-center">


        <a href="{{ config('app.url') }}/{{ $urlshoter }}">
            {{ config('app.url') }}/{{ $urlshoter }}
        </a>
    </div>
</div>

@endsection