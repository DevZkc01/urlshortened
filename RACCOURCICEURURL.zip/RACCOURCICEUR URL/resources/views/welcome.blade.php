@extends('layouts.master')

@section('content')

@include('navbar.navbar')

<div class="container mt-4">
    <div class="row">
        <form class="d-flex" action="/" method="POST">
            @csrf
            <div class="form-group">
                <input name="lien" class="form-control @error('lien') is-invalid @enderror me-2" type="text"
                    placeholder="Enter Your Link" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">Valide</button>
                <span class="text-center">
                    @error('lien')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                </span>
            </div>
        </form>
    </div>

    <div class="row text-center">

    </div>
</div>

@endsection